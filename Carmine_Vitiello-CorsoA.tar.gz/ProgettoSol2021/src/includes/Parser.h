Queue* parser(char* argv[],int argc);
char* savefiledir;
int seenr;
int seenR;
int timems;
int verbose;
char* socknameconfig;
int seenf;
int seenp;